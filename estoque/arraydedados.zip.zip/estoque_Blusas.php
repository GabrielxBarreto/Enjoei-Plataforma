<?php
$blusas =  [
    [
        "nome"=>"blusa feminina linho",
        "preco"=>75.00,
        "desconto" => 38.00,
        "condicao"=>"usado",
        "descricao" => "tamanho 44
        perfeitas condições
        tecido leve",
        "pecasEmEstoque" => 146,
        "img" => "../img_produtos/blusalinho.jpg",
        "marca" => "seiki"
    ],
    [
        "nome"=>"blusa feminina de lã metalizada",
        "preco"=>120.00,
        "desconto" => 114.00,
        "condicao"=>"usado",
        "descricao" => "blusa feminina de lã metalizada, manga longa com gola em v, bem quentinha, sem manchas ou avarias
        medidas
        ombro a ombro: 40cm
        comprimento da manga: 70cm
        comprimento: 77cm",
        "pecasEmEstoque" => 500,
        "img" => "../img_produtos/blusala.jpg",
        "marca" => "-"
    ],
    [
        "nome"=>"blusa feminina camiseta acinturada cor abóbora tamanho g",
        "preco"=>59.00,
        "desconto" => 56.00,
        "condicao"=>"usado",
        "descricao" => "blusa feminina, acinturada, alongada, cor abóbora, detalhe dourado na gola. lindaa, atemporal e em estado de nv. peça única, perde não! veste m/g
        medidas: compri 68, bus 106 cint 100.
        
        outono inverno moda camisa alfaiataria calça alfaiataria social trabalho casual vintage bata túnica saída linho blusa branca pareô blusa feminina",
        "pecasEmEstoque" => 2000,
        "img" => "../img_produtos/blusarosaf.jpg",
        "marca" => "camaleoa"
    ],
    [
        "nome"=>"blusa masculina acostamento",
        "preco"=>150.00,
        "desconto" => false,
        "condicao"=>"usado",
        "descricao" => "blusa meia estação
        azul marinho
        detalhe na manga em jeans
        tam m
        em perfeita condições
        com capuz
        serve p e m",
        "pecasEmEstoque" => 20,
        "img" => "../img_produtos/blusamasc.jpg",
        "marca" => "acostamento"
    ],
    [
        "nome"=>"blusa mostarda surfari",
        "preco"=>90.00,
        "desconto" => 64.00,
        "condicao"=>"novo",
        "descricao" => "blusa unissex
        p masculino p/m feminino
        carinha de vintage mas é novinha
        nunca usada
        estampa legal e divertida",
        "pecasEmEstoque" => 50,
        "img" => "../img_produtos/blusasufari.jpg",
        "marca" => "-"
    ],
    [
        "nome"=>"blusa moleton adidas",
        "preco"=>150.00,
        "desconto" => 130.00,
        "condicao"=>"novo",
        "descricao" => "original e nunca usada.
        tamanho m
        feminina.",
        "pecasEmEstoque" => 25,
        "img" => "../img_produtos/moletonadidas.jpg",
        "marca" => "adidas"
    ],
    [
        "nome"=>"moletom adidas",
        "preco"=>80.00,
        "desconto" => false,
        "condicao"=>"usado",
        "descricao" => "maravilhoso moletom adidas preto. tamanho p. unisex.",
        "pecasEmEstoque" => 62,
        "img" => "../img_produtos/adidasmoletondois.jpg",
        "marca" => "adidas"
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
]
?>