<?php
$calcas =  [
    [
        "nome"=>"nome_1",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao" => "lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome"=>"nome_2",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome"=>"nome_3",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome"=>"nome_4",
        "preco"=> 1.0,
        "desconto" => false,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
    [
        "nome" => "nome_5",
        "preco"=> 1.0,
        "desconto" => true,
        "descricao"=>"lorem ipsum dolor sit amet, consectet morbi tristique senectus et netus et malesuada",
        "pecasEmEstoque" => 5
    ],
]
?>